<?php 
// Website Name
$webName = "AniKatsu";
// Website URL
$webUrl = "//{$_SERVER['SERVER_NAME']}";
// Logo
$webLogo = $webUrl ."/files/images/logo.png";

// Socials 
// 1 . Donate 
$donate = "https://r.honeygain.me/DEVEL77939";
// 2 . Telegram
$telegram = "https://t.me/Anikatsu";
// 3 . Discord 
$discord = "#";
// 4 Redit
$redit = "#";
// Twitter
$twitter = "#";



// API URL (Don't edit)

$apiLink = "https://anikatsu.vercel.app/api";
$banner = $webUrl . "/files/images/banner.png"
?>
